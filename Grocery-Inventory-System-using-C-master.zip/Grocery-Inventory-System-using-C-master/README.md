# Inventory-System
Developed a project for e-food system that allows to keep track of items in a supermarket.

Implemented in C language and used file I/O for persistence storage.
