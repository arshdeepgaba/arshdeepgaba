# Aid-Managment-System

Implemented an application that keeps a record of perishable and non-perishable products to be shipped to the victims of a disaster.

Programmed in C++ language using concepts like Interface, Encapsulation and used file I/O for the storage.

