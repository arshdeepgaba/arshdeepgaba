package com.example.myapplication;

import android.content.DialogInterface;
import android.database.Cursor;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private final static String TAG = "MainActivity";

    DatabaseHelper mDatabaseHelper;
    private Button btn1;
    private Button btn2;
    private Button btn3;
    private Button btn4;

    private EditText editText1;
    private EditText editText2;
    private EditText editText3;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText1 = (EditText) findViewById(R.id.id_number);
        editText2 = (EditText) findViewById(R.id.name);
        editText3 = (EditText) findViewById(R.id.marks);
        mDatabaseHelper = new DatabaseHelper(this);
        btn1 = (Button) findViewById(R.id.addData);
        btn2 = (Button) findViewById(R.id.viewStudent);
        btn3 = (Button) findViewById(R.id.findStudent);
        btn4 = (Button) findViewById(R.id.deleteStudent);


        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id_ = editText1.getText().toString();
                String name_ = editText2.getText().toString();
                String marks_ = editText3.getText().toString();
                if (id_.matches("") || name_.matches("") || marks_.matches("")) {
                    toastMessage("Incomplete");

                } else {

                    int intID = Integer.parseInt(id_);
                    int intMarks = Integer.parseInt(marks_);

                    AddData(intID, name_, intMarks);

                    AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                    alertDialog.setTitle("The following student was added");
                    alertDialog.setMessage("ID:" + id_ + " Name:" + name_ + " Marks:" + marks_);
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Close",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
                editText1.getText().clear();
                editText2.getText().clear();
                editText3.getText().clear();

            }


        });


        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Cursor data = mDatabaseHelper.getData();
                String all = "";
                while (data.moveToNext()) {
                    String id_ = data.getString(0);
                    String name_ = data.getString(1);
                    String marks_ = data.getString(2);
                    all += "ID:" + id_ + " Name:" + name_ + " Marks:" + marks_ + "\n";
                }

                if (all.matches("")) {
                    AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                    alertDialog.setTitle("No students were found");
                    //  alertDialog.setMessage(all);
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Close",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                } else {
                    AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                    alertDialog.setTitle("The following student have been added");
                    alertDialog.setMessage(all);
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Close",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                }
            }
        });

        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id1 = editText1.getText().toString();

                if (id1.matches("")) {
                    AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                    alertDialog.setTitle("The student does not exist");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Close",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                } else {
                    int intID = Integer.parseInt(id1);
                    Cursor data = mDatabaseHelper.findData(intID);
                    String all = "";
                    while (data.moveToNext()) {
                        String id_ = data.getString(0);
                        String name_ = data.getString(1);
                        String marks_ = data.getString(2);
                        all += "ID:" + id_ + " Name:" + name_ + " Marks:" + marks_ + "\n";
                    }

                    if (all.matches("") == false) { // the string is not empty
                        AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                        alertDialog.setTitle("Student details are as follows");
                        alertDialog.setMessage(all);
                        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Close",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        alertDialog.show();
                        editText1.getText().clear();
                    } else { //otherwise
                        AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                        alertDialog.setTitle("The student does not exist");
                        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Close",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        alertDialog.show();
                        editText1.getText().clear();
                    }

                }
            }
        });


        btn4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String id1 = editText1.getText().toString();
                if (id1.matches("") == false) { //if the string is not empty
                    int intID = Integer.parseInt(id1);
                    String all = mDatabaseHelper.delete(intID);

                    if(all.matches("")==false) {
                        AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                        alertDialog.setTitle("The following student has been deleted");
                        alertDialog.setMessage(all);
                        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Close",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        alertDialog.show();
                        editText1.getText().clear();
                    }
                    else{
                        AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                        alertDialog.setTitle("The student does not exist");
                        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Close",
                                new DialogInterface.OnClickListener() {
                                    public void onClick(DialogInterface dialog, int which) {
                                        dialog.dismiss();
                                    }
                                });
                        alertDialog.show();
                        editText1.getText().clear();
                    }

                } else {
                    AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
                    alertDialog.setTitle("The student does not exist");
                    alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "Close",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();
                                }
                            });
                    alertDialog.show();
                    editText1.getText().clear();
                }
            }
        });


    }


    public void AddData(int id_, String name_, int marks_) {
        boolean insertData = mDatabaseHelper.addData(id_, name_, marks_); //calling the function from the DatabaseHelper Class

    }


    private void toastMessage(String str) {
        Toast.makeText(this, str, Toast.LENGTH_LONG).show();
    }
}
