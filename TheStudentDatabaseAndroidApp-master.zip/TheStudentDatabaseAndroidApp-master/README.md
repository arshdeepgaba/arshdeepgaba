# TheStudentDataBaseSQLiteApp

Build an android app to keep record of students using SQLite database.

The app has the option to add new students, view all the students, find a student using ID and the option to delete the students using ID.
