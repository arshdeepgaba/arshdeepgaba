# SportsInfoImageApp

Build an android app to keep record of sport teams using SQLite database.

The app has the option to update and delete the stored information and also to upload an image for a team from the phone's gallery. The app needs user's permission to open the gallery.

Implemented spinner to restrict the user from selecting the game only from a provided list.

Clicking on any row in the list view will open a new page with detailed information about the team and the page will have the options to changes/edit the data.
