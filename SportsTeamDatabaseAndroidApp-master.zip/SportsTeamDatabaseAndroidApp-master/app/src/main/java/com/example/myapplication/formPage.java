package com.example.myapplication;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class formPage  extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    DatabaseHelper mDatabaseHelper;
    final int REQUEST_CODE_GALLERY = 999;

    private Button btn1;
    private Button btn2;
    private Button btn3;

    private EditText editText1;
    private EditText editText2;
    // private EditText editText3;
    private EditText editText4;
    private ImageView imageView;
    private Spinner spinner;


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        //help   Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_page);
        mDatabaseHelper = new DatabaseHelper(this);

        editText1 = (EditText) findViewById(R.id.fromPageCity);
        editText2 = (EditText) findViewById(R.id.formPageName);
        //  editText3 = (EditText) findViewById(R.id.formPageSport);
        editText4 = (EditText) findViewById(R.id.formPageMVP);
        imageView = (ImageView) findViewById(R.id.formPageImage);
        //     editText5 = (EditText) findViewById(R.id.formPageStadium);


        spinner = findViewById(R.id.formPageSport);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.numbers, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);


        btn1 = (Button) findViewById(R.id.formPageSubmitButton);
        btn1.setOnClickListener(new View.OnClickListener() { //The submit button
            @Override
            public void onClick(View v) {
                String city = editText1.getText().toString();
                String name = editText2.getText().toString();
                String sport = spinner.getSelectedItem().toString();
                String mvp = editText4.getText().toString();
                byte[] image = imageViewToByte(imageView);


                if (city.matches("") || name.matches("")) {
                    toastMessage("City and Name are required.");

                } else {
                    AddData(city, name, sport, mvp, image);
                    //       String s = city + " " + name + " " + sport + " " + mvp;

                }
                editText1.getText().clear();
                editText2.getText().clear();
                //editText3.getText().clear();
                editText4.getText().clear();
                imageView.setImageResource(R.drawable.capture);
                spinner.setSelection(0);

                // editText5.getText().clear();
            }


            private byte[] imageViewToByte(ImageView img) {
                Bitmap bitmap = ((BitmapDrawable) img.getDrawable()).getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] byteArray = stream.toByteArray();
                return byteArray;

            }

        });


        btn2 = (Button) findViewById(R.id.formPageExitButton);
        btn2.setOnClickListener(new View.OnClickListener() { //The exit button
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(formPage.this, MainActivity.class); // doing this so that the previous page get refreshed
                startActivity(intent);

            }
        });


        btn3 = (Button) findViewById(R.id.formPageUploadBtn);
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityCompat.requestPermissions(formPage.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_CODE_GALLERY);


                // ActivityCompat.requestPermissions(formPage.this,new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},1);


            }
        });


    }


//    public void OnRequestPermissionsResult(int requestCode,  String[] permissions,  int[] grantResults) {
//        if (requestCode == REQUEST_CODE_GALLERY) {
//            //   Toast.makeText(getApplicationContext(), "XXXXX2", Toast.LENGTH_LONG).show();
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                Intent intent = new Intent(Intent.ACTION_PICK);
//                intent.setType("image/*");
//                startActivityForResult(intent, REQUEST_CODE_GALLERY);
//            } else {
//                Toast.makeText(getApplicationContext(), "You don't have the permission to access the files", Toast.LENGTH_SHORT).show();
//            }
//            return;
//        }
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (requestCode == REQUEST_CODE_GALLERY) {
            //   Toast.makeText(getApplicationContext(), "XXXXX2", Toast.LENGTH_LONG).show();
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, REQUEST_CODE_GALLERY);
            } else {
                Toast.makeText(getApplicationContext(), "You don't have the permission to access the files", Toast.LENGTH_SHORT).show();
            }
            return;
        }
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        Uri uri = data.getData();

        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            imageView.setImageBitmap(bitmap);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }


    public void AddData(String city_, String name_, String sport_, String mvp_, byte[] image_) {
        boolean insertData = mDatabaseHelper.addData(city_, name_, sport_, mvp_, image_);
    }

    private void toastMessage(String str) {
        Toast.makeText(this, str, Toast.LENGTH_LONG).show();
    }

    @Override
    public void onBackPressed() {

    }


}
