package com.example.myapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String TAG = "DataBaseHelper";
    private static final String tableName = "team";
    private static final String COL1 = "city";
    private static final String COL2 = "name";
    private static final String COL3 = "sport";
    private static final String COL4 = "mvp";
    private static final String COL5 = "image";
    //  private static final String COL5 = "image";


    public DatabaseHelper(Context context) {
        super(context, tableName, null, 1);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + tableName);
        onCreate(db);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + tableName + " (" + COL1 + " TEXT, " + COL2 + " TEXT, " + COL3 + " Text, " + COL4 + " TEXT, " + COL5 + " BLOB)";
        db.execSQL(createTable);
    }

    public boolean addData(String city_, String name_, String sport_, String mvp_, byte[] image_) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(COL1, city_);
        contentValues.put(COL2, name_);
        contentValues.put(COL3, sport_);
        contentValues.put(COL4, mvp_);
        contentValues.put(COL5, image_);

        Log.d(TAG, "Adding data to the " + tableName);

        long result = db.insert(tableName, null, contentValues);

        if (result == -1) { // this condition let us know if the operation was successful or not
            return false;
        } else {
            return true;
        }

    }

    public Cursor getData() {
        SQLiteDatabase db = this.getWritableDatabase();
        String query = "SELECT * FROM " + tableName;
        Cursor data = db.rawQuery(query, null);
        return data;
    }

    public Cursor findData(String number, String num) {
        SQLiteDatabase db = this.getReadableDatabase();
        number = '"' + number + '"';
        num = '"' + num + '"';
        Cursor data = db.rawQuery("SELECT * FROM " + tableName + " WHERE " + COL2 + " = " + num + " AND " + COL1 + " = " + number, null);
        return data;
    }


    public void delete(String number, String num) {
        SQLiteDatabase db = this.getReadableDatabase();
        number = '"' + number + '"';
        num = '"' + num + '"';
//        Cursor data=db.rawQuery("SELECT * FROM "+ tableName + " WHERE " + COL1 + " = " + number,null);
//        String all = "";
//        while (data.moveToNext()) {
//            String id_ = data.getString(0);
//            String name_ = data.getString(1);
//            String marks_ = data.getString(2);
//            all += "ID:" + id_ + " Name:" + name_ + " Marks:" + marks_ + "\n";
//        }


        db.delete(tableName, COL1 + " = " + number + " AND " + COL2 + " = " + num, null);
        //     return all;


    }

}
