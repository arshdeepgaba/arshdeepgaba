package com.example.myapplication;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;

public class finalPage  extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    final int REQUEST_CODE_GALLERY = 999;
    private Button btn;
    DatabaseHelper databaseHelper;
    private ImageView imageView;
    byte[] image_;
    private Button btn2;
    private Button btn3;
    private Button btn4;
    private Spinner spinner;

    EditText textView;
    EditText textView2;
    EditText textView4;


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
        //help   Toast.makeText(parent.getContext(), text, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_final_page);
        databaseHelper = new DatabaseHelper(this);

        Intent intent = getIntent();
        String str = intent.getStringExtra("string");
        textView = (EditText) findViewById(R.id.finalPageCity);
        textView2 = (EditText) findViewById(R.id.finalPageName);
        //  EditText textView3 = (EditText) findViewById(R.id.finalPageSport);
        textView4 = (EditText) findViewById(R.id.finalPageMVP);
        imageView = (ImageView) findViewById(R.id.finalPageImage);
        //     TextView textView5 = (TextView) findViewById(R.id.finalPageStadium);

        spinner = findViewById(R.id.finalPageSport);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.numbers, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);


        String s = str;
        String str1 = "";
        String str2 = "";
        int x = 0;
        for (int i = 0; i < s.length(); i++) {
            if (s.charAt(i) == ' ') {
                break;
            }
            str1 += s.charAt(i);
            x++;
        }

        for (int j = x + 1; j < s.length(); j++) {
            str2 += s.charAt(j);
        }
        final String dupStr1 = str1;
        final String dupStr2 = str2;

        //    textView.setText("-"+str1 + "-" + str2+"-");
        Cursor data = databaseHelper.findData(str1, str2);


        String city_ = "";
        String name_ = "";
        String sport_ = "";
        String mvp_ = "";

        //   String stadium_ = "";
        while (data.moveToNext()) {
            city_ = data.getString(0);
            name_ = data.getString(1);
            sport_ = data.getString(2);
            mvp_ = data.getString(3);
            image_ = data.getBlob(4);
            //      stadium_ = data.getString(4);
        }

        int index_ = 0;
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(sport_)) {
                index_ = i;
            }
        }

        textView.setText(city_);
        textView2.setText(name_);
        //  textView3.setText(sport_);
        textView4.setText(mvp_);
        //      textView5.setText(stadium_);


        //set the spinner
        spinner.setSelection(index_);


        imageView.setImageBitmap(BitmapFactory.decodeByteArray(image_, 0, image_.length));

        //above this point

        btn = (Button) findViewById(R.id.finalPageExitButton);
        btn.setOnClickListener(new View.OnClickListener() { //The exit button
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(finalPage.this, MainActivity.class);
                startActivity(intent);

            }
        });


        btn2 = (Button) findViewById(R.id.finalPageDelete);
        btn2.setOnClickListener(new View.OnClickListener() { //The exit button
            @Override
            public void onClick(View v) {
                databaseHelper.delete(dupStr1, dupStr2);
                Intent intent = new Intent(finalPage.this, MainActivity.class);
                startActivity(intent);
            }
        });


        btn3 = (Button) findViewById(R.id.finalPageUpdate);
        btn3.setOnClickListener(new View.OnClickListener() { //The exit button
            @Override
            public void onClick(View v) {

                databaseHelper.delete(dupStr1, dupStr2);


                String city = textView.getText().toString();
                String name = textView2.getText().toString();
                String sport = spinner.getSelectedItem().toString();
                String mvp = textView4.getText().toString();
                byte[] image = imageViewToByte(imageView);


                if (city.matches("") || name.matches("")) {
                    toastMessage("City and Name are required.");

                } else {
                    AddData(city, name, sport, mvp, image);
                    //       String s = city + " " + name + " " + sport + " " + mvp;

                }
                Intent intent = new Intent(finalPage.this, MainActivity.class);
                startActivity(intent);


            }

            private byte[] imageViewToByte(ImageView img) {
                Bitmap bitmap = ((BitmapDrawable) img.getDrawable()).getBitmap();
                ByteArrayOutputStream stream = new ByteArrayOutputStream();
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, stream);
                byte[] byteArray = stream.toByteArray();
                return byteArray;

            }

        });


        btn4 = (Button) findViewById(R.id.finalPageUploadBtn);
        btn4.setOnClickListener(new View.OnClickListener() { //The exit button
            @Override
            public void onClick(View v) {
                ActivityCompat.requestPermissions(finalPage.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQUEST_CODE_GALLERY);

            }
        });


    }


    @Override
    public void onBackPressed() {

    }


    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {
        if (requestCode == REQUEST_CODE_GALLERY) {
            //   Toast.makeText(getApplicationContext(), "XXXXX2", Toast.LENGTH_LONG).show();
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");
                startActivityForResult(intent, REQUEST_CODE_GALLERY);
            } else {
                Toast.makeText(getApplicationContext(), "You don't have the permission to access the files", Toast.LENGTH_SHORT).show();
            }
            return;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        Uri uri = data.getData();

        try {
            InputStream inputStream = getContentResolver().openInputStream(uri);
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            imageView.setImageBitmap(bitmap);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }


    public void AddData(String city_, String name_, String sport_, String mvp_, byte[] image_) {
        boolean insertData = databaseHelper.addData(city_, name_, sport_, mvp_, image_);
    }

    private void toastMessage(String str) {
        Toast.makeText(this, str, Toast.LENGTH_LONG).show();
    }


}