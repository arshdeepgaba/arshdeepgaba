# TheEarthquakeApp

Built an android app to display a list of recent earthquakes all around the world.

The user has the option to choose the sorting parameter(magnitude/date) and the number of earthquakes to be shown.

Clicking on any row in the list view will open a website with more detailed information about that particular earthquake in the phone's default browser.
